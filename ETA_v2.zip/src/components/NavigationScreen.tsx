import React, { useState, useEffect } from "react";
import { ChevronRight, Info, AlertTriangle, ShieldCheck, MapPin, RefreshCw, Layers } from "lucide-react";
import { RouteInfo, RouteSegment } from "../types";
import { KakaoMap } from "./KakaoMap";
import { PaceBar } from "./PaceBar";

interface NavigationScreenProps {
  route: RouteInfo;
  origin: { name: string; lat: number; lng: number };
  destination: { name: string; lat: number; lng: number };
  speedFactor: number;
  onFinish: () => void;
  showToast: (msg: string) => void;
}

export function NavigationScreen({
  route,
  origin,
  destination,
  speedFactor,
  onFinish,
  showToast
}: NavigationScreenProps) {
  const [navIndex, setNavIndex] = useState<number>(0);
  const [routeRevision, setRouteRevision] = useState<number>(1);
  const [navSteps, setNavSteps] = useState<RouteSegment[]>([...route.segments]);
  const [personalEta, setPersonalEta] = useState<number>(route.personal);
  const [gpsIndicator, setGpsIndicator] = useState<string>("수신 양호 (정확도: 3.8m)");
  const [gpsPulse, setGpsPulse] = useState<boolean>(false);
  const [currentStation, setCurrentStation] = useState<string | null>(null);
  const [rerouteSuggested, setRerouteSuggested] = useState<boolean>(false);

  // 1. Send GPS signals every 5 seconds (Section 5, F-NAV-02: coordinates are processed serverless, discarded from DB)
  useEffect(() => {
    const interval = setInterval(() => {
      setGpsPulse(true);
      const randomAccuracy = (2.5 + Math.random() * 3).toFixed(1);
      setGpsIndicator(`정밀 좌표 전송 완료 (오차: ${randomAccuracy}m) - 기록 즉시 전량 폐기됨`);
      setTimeout(() => setGpsPulse(false), 800);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleNextStep = () => {
    if (navIndex + 1 >= navSteps.length) {
      onFinish();
    } else {
      setNavIndex(navIndex + 1);
    }
  };

  // F-NAV-04: Missed Transit Reroute event
  const handleMissedTransit = (mode: string) => {
    const nextRevision = routeRevision + 1;
    setRouteRevision(nextRevision);
    showToast(`대중교통 놓침이 수신되어 경로 개정(routeRevision=${nextRevision})을 갱신합니다.`);

    const delayMin = 6 + Math.round(Math.random() * 5);
    setPersonalEta((prev) => prev + delayMin);

    const updated = [...navSteps];
    const currentSeg = updated[navIndex];
    if (currentSeg) {
      currentSeg.title = `[대기 보정] ${currentSeg.title}`;
      currentSeg.desc = `다음 저상수단 배차 대기(${delayMin}분) 및 수평 환승 시간표 재조율 결과를 반영했습니다.`;
      currentSeg.time = `${parseInt(currentSeg.time) + delayMin}분`;
      setNavSteps(updated);
    }
  };

  // F-NAV-05: Underground GPS Manual Station Override
  const handleStationSnap = (stationName: string) => {
    setCurrentStation(stationName);
    const nextRevision = routeRevision + 1;
    setRouteRevision(nextRevision);
    setGpsIndicator(`지하 역사 보완 수동 연동: [${stationName}] 잠금 고정됨`);
    showToast(`지하 GPS 보정이 감지되었습니다. 역사 좌표 기준 재산출 완료(routeRevision=${nextRevision})`);

    // Speed up or adjust somewhat
    const updated = [...navSteps];
    const currentSeg = updated[navIndex];
    if (currentSeg) {
      currentSeg.desc = `[지하철역 보완] 현재 ${stationName} 역사 좌표를 강제 매핑하여 위치 불통 문제를 복구했습니다.`;
      setNavSteps(updated);
    }
  };

  // F-NAV-03: Simulate automatic off-track deviation detection
  const triggerMockDeviation = () => {
    setRerouteSuggested(true);
    showToast("경로 이탈이 임시 감지되었습니다! (REROUTE_SUGGESTED)");
  };

  const approveReroute = () => {
    const nextRevision = routeRevision + 1;
    setRouteRevision(nextRevision);
    setRerouteSuggested(false);
    setPersonalEta((prev) => prev + 4);
    
    // update current segment
    const updated = [...navSteps];
    updated.splice(navIndex, 0, {
      mode: "walk",
      title: "⚠️ [경로 이탈 복구] 대체 보행 우회로",
      desc: "계단 공사 및 높은 턱 회피를 위한 대체 인도로 안전하게 재합류합니다.",
      time: "4분",
      tags: ["우회 완만로"],
      facilityStatus: "ACCESSIBLE"
    });
    setNavSteps(updated);
    showToast(`이탈 보정 및 새 안전 경로 갱신 완료(routeRevision=${nextRevision})`);
  };

  return (
    <div className="flex-1 flex flex-col" id="view-navigation-screen">
      {/* Dynamic Header Stats */}
      <div className="bg-slate-900 text-white px-5 py-3.5 flex justify-between items-center shrink-0">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
          <span className="text-[12px] font-black text-emerald-400">STATUS: ACTIVE</span>
        </div>
        <div className="flex items-center gap-3 text-[11px] font-mono font-bold text-slate-400">
          <span>경로 개정: <b className="text-white">v{routeRevision}</b></span>
          <span>남은 맞춤시간: <b className="text-emerald-400">{personalEta}분</b></span>
        </div>
      </div>

      {/* Map display */}
      <div className="h-[210px] relative shrink-0">
        <KakaoMap
          center={origin}
          level={4}
          markers={[
            { lat: origin.lat + 0.0004, lng: origin.lng + 0.0004, title: "나의 위치", type: "you" },
            { lat: destination.lat, lng: destination.lng, title: destination.name, type: "dest" }
          ]}
          routePath={(route as any).mapPoints || []}
        />

        {/* GPS Active Ticker Status */}
        <div className="absolute bottom-3 left-4 right-4 bg-slate-950/80 backdrop-blur px-3 py-1.5 rounded-lg text-[10.5px] font-mono font-bold text-slate-200 z-10 flex items-center justify-between shadow">
          <span className="flex items-center gap-1.5 truncate">
            <span className={`w-2 h-2 rounded-full ${gpsPulse ? "bg-amber-400 scale-125" : "bg-emerald-400"} transition-all`}></span>
            {gpsIndicator}
          </span>
          <span className="text-blue-400 text-[9.5px]">GPS 5s</span>
        </div>

        {/* Trigger Mock Drift button */}
        <button
          onClick={triggerMockDeviation}
          className="absolute top-3 right-3 bg-white/90 backdrop-blur p-2 rounded-xl shadow border border-slate-200 text-slate-700 text-[10.5px] font-bold hover:bg-slate-100 transition-all z-10 flex items-center gap-1 cursor-pointer"
        >
          <Layers className="w-3.5 h-3.5 text-blue-600 animate-pulse" />
          가상 이탈(Reroute)
        </button>
      </div>

      {/* Navigation directions list & controls */}
      <div className="flex-1 bg-white border-t border-slate-200 shadow flex flex-col overflow-hidden">
        
        {/* Active navigation instruction card */}
        <div className="bg-blue-600 text-white p-4.5 shrink-0 relative">
          <div className="flex justify-between items-start mb-1.5">
            <div>
              <span className="text-[10px] font-black uppercase tracking-widest opacity-80 block">
                전체 {navSteps.length}개 턱 완화 리스트 중 ({navIndex + 1} / {navSteps.length})
              </span>
              <h3 className="text-[17px] font-black tracking-tight mt-0.5">
                {navSteps[navIndex]?.title || "최종 목적지에 거의 도착했습니다."}
              </h3>
            </div>
            {navSteps[navIndex]?.time && (
              <div className="text-right">
                <span className="text-[20px] font-mono font-black leading-none block text-amber-300">
                  {navSteps[navIndex].time}
                </span>
                <span className="text-[9.5px] opacity-75">구간 시간</span>
              </div>
            )}
          </div>

          <p className="text-[13px] opacity-90 leading-relaxed">
            {navSteps[navIndex]?.desc}
          </p>

          <div className="flex items-center gap-3 border-t border-white/20 mt-3 pt-2">
            <span className="text-[10.5px] font-bold opacity-85 shrink-0">개인 보행 템포 속도 박자</span>
            <PaceBar speedFactor={speedFactor} />
          </div>
        </div>

        {/* Deviation Suggestion Modal Popup */}
        {rerouteSuggested && (
          <div className="bg-amber-50 border-b border-amber-200 px-4 py-3 shrink-0 flex items-start gap-3 animate-fade-in">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div className="min-w-0 flex-1">
              <h4 className="text-[12.5px] font-black text-amber-800">⚠️ 경로 이탈 감지 (REROUTE_SUGGESTED)</h4>
              <p className="text-[11px] text-amber-700 leading-normal mt-0.5">
                안전 보행망 분석 결과 오차가 20m 이상 어긋났습니다. 안전 우회 경로로 재산출하시겠습니까?
              </p>
              <div className="flex gap-2.5 mt-2">
                <button
                  onClick={approveReroute}
                  className="bg-amber-600 hover:bg-amber-700 text-white text-[11px] font-bold py-1 px-3 rounded-md cursor-pointer shadow-sm transition-all"
                >
                  새 경로 재탐색 승인
                </button>
                <button
                  onClick={() => setRerouteSuggested(false)}
                  className="text-amber-800 text-[11px] font-bold py-1 px-2.5 hover:bg-amber-100 rounded-md cursor-pointer transition-all"
                >
                  이탈 무시
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Underground GPS snaps override (F-NAV-05) */}
        <div className="bg-slate-50 border-b border-slate-200 px-4 py-2 shrink-0 flex items-center justify-between gap-2 overflow-x-auto custom-scrollbar">
          <span className="text-[10.5px] font-bold text-slate-500 flex items-center gap-1 shrink-0">
            <MapPin className="w-3.5 h-3.5 text-blue-600" />
            지하 GPS 불통 보정역 지정:
          </span>
          <div className="flex gap-1.5 shrink-0 py-0.5">
            {["강남역", "역삼역", "보라매역", "서울역"].map((st) => (
              <button
                key={st}
                onClick={() => handleStationSnap(st)}
                className={`text-[10px] font-bold px-2 py-0.8 rounded-md border transition-all cursor-pointer ${
                  currentStation === st
                    ? "bg-blue-600 text-white border-blue-600"
                    : "bg-white text-slate-600 border-slate-200 hover:border-blue-500"
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        {/* Steps sequence timeline */}
        <div className="flex-1 overflow-y-auto px-5 py-3.5 custom-scrollbar bg-slate-50">
          <div className="space-y-1.5">
            {navSteps.map((step, idx) => {
              const isCompleted = idx < navIndex;
              const isActive = idx === navIndex;
              return (
                <div
                  key={idx}
                  className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${
                    isActive
                      ? "bg-white border-blue-600 shadow-sm"
                      : "bg-slate-100/60 border-slate-200"
                  } ${isCompleted ? "opacity-45" : ""}`}
                >
                  <span className={`w-5.5 h-5.5 rounded-full flex items-center justify-center font-mono text-[10px] font-black shrink-0 ${
                    isCompleted ? "bg-blue-600 text-white" : "bg-slate-200 text-slate-500"
                  }`}>
                    {isCompleted ? "✓" : idx + 1}
                  </span>
                  <div className="min-w-0 flex-1">
                    <h4 className="text-[12.5px] font-bold text-slate-900">{step.title}</h4>
                    <p className="text-[11px] text-slate-500 truncate">{step.desc}</p>
                  </div>
                  {step.facilityStatus === "UNKNOWN" && (
                    <span className="bg-amber-100 text-amber-700 font-bold px-1.5 py-0.5 rounded text-[9px] uppercase shrink-0">
                      UNKNOWN
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Control triggers */}
        <div className="p-3.5 bg-slate-100 border-t border-slate-200 shrink-0 flex gap-2.5">
          {(navSteps[navIndex]?.mode === "bus" || navSteps[navIndex]?.mode === "subway") && (
            <button
              onClick={() => handleMissedTransit(navSteps[navIndex].mode)}
              className="py-2.5 px-3.5 bg-red-50 hover:bg-red-100 text-red-600 font-bold rounded-xl text-[12.5px] transition-all border border-red-100 cursor-pointer"
            >
              차량을 놓쳤어요
            </button>
          )}
          <button
            onClick={handleNextStep}
            className="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-[13.5px] flex items-center justify-center gap-1.5 shadow-sm transform active:scale-95 transition-all cursor-pointer"
          >
            <span>{navIndex + 1 === navSteps.length ? "목적지 하차 완료" : "다음 위험턱 확인"}</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
}
