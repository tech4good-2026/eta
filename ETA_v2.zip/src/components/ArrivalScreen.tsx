import React, { useEffect, useState } from "react";
import { Check, RefreshCw, ShieldCheck, Home, LogOut, Trash2 } from "lucide-react";
import { RouteInfo, UserProfile } from "../types";
import { learnWalkingSpeed, signOutUser } from "../utils/auth";
import { PaceBar } from "./PaceBar";

interface ArrivalScreenProps {
  email: string;
  route: RouteInfo;
  currentSpeed: number;
  onHome: (nextProfile: UserProfile) => void;
  onLogout: () => void;
  showToast: (msg: string) => void;
}

export function ArrivalScreen({
  email,
  route,
  currentSpeed,
  onHome,
  onLogout,
  showToast
}: ArrivalScreenProps) {
  const [learningReport, setLearningReport] = useState<{
    previousSpeed: number;
    newSpeed: number;
    samples: number;
  } | null>(null);

  // F-PROFILE-03 / F-NAV-06: Trigger self-learning speed calculations when this screen boots!
  useEffect(() => {
    try {
      // Simulate that the user walked slightly faster or slower than their initial calculated pace
      // We will generate a mock observed walking speed that is very realistic
      const drift = 0.03 + Math.random() * 0.08;
      const isPositive = Math.random() > 0.4;
      const observedSpeed = parseFloat(
        (isPositive ? currentSpeed + drift : Math.max(0.45, currentSpeed - drift)).toFixed(2)
      );

      // Perform updates in database
      const updatedUser = learnWalkingSpeed(email, observedSpeed);
      
      setLearningReport({
        previousSpeed: currentSpeed,
        newSpeed: updatedUser.profile.walkingSpeedMps,
        samples: updatedUser.profile.walkingSpeedSampleCount
      });

      showToast(`ETA 자동 보정 엔진 가동: 다음 이동 소요시간이 더욱 정밀해집니다!`);
    } catch (err: any) {
      console.error("Speed learning failed", err);
    }
  }, [email, currentSpeed]);

  const handleSignOut = () => {
    signOutUser();
    showToast("안전하게 로그아웃 처리되었습니다.");
    onLogout();
  };

  return (
    <div className="flex-1 flex flex-col justify-between px-6 py-6 overflow-y-auto custom-scrollbar bg-slate-50" id="view-arrival-screen">
      <div className="text-center pt-3">
        {/* Animated Check circle */}
        <div className="w-[66px] h-[66px] rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto mb-4.5 border border-emerald-100 shadow-sm animate-pulse">
          <Check className="w-[32px] h-[32px]" />
        </div>
        <h1 className="text-[21.5px] font-black text-slate-900 mb-1">안전하게 완주했습니다!</h1>
        <p className="text-[13px] text-slate-500 leading-relaxed">
          장애물과 가파른 턱을 무사히 회회하여 맞춤 목적지에 안착 완료했습니다.
        </p>
      </div>

      {/* Stats Board */}
      <div className="grid grid-cols-3 gap-2 py-4">
        <div className="bg-white border border-slate-200 p-3 rounded-2xl text-center shadow-sm">
          <span className="block text-[10px] text-slate-400 font-bold mb-0.5">실제 완주 소요</span>
          <b className="text-[16px] font-mono text-blue-600">{route.personal}분</b>
        </div>
        <div className="bg-white border border-slate-200 p-3 rounded-2xl text-center shadow-sm">
          <span className="block text-[10px] text-slate-400 font-bold mb-0.5">환승 수단</span>
          <b className="text-[16px] font-mono text-blue-600">{route.transfers}회</b>
        </div>
        <div className="bg-white border border-slate-200 p-3 rounded-2xl text-center shadow-sm">
          <span className="block text-[10px] text-slate-400 font-bold mb-0.5">지불 요금</span>
          <b className="text-[16px] font-mono text-blue-600">
            {route.fare > 0 ? `${route.fare.toLocaleString()}원` : "0원"}
          </b>
        </div>
      </div>

      {/* Speed Self-learning Report block */}
      <div className="bg-white border border-slate-200 rounded-[22px] p-4.5 shadow-sm space-y-3">
        <h4 className="text-[13px] font-black text-slate-900 flex items-center gap-1.5">
          <RefreshCw className="w-4 h-4 text-amber-500 animate-spin" />
          ETA 걷기속도 정밀보정 리포트
        </h4>
        <p className="text-[11.5px] text-slate-500 leading-normal">
          안내 중 수집된 원본 좌표는 DB에 저장되지 않고 모두 폐기되었으며, 유효한 보행 속도 집계 분석결과만 보강되었습니다.
        </p>

        {learningReport && (
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 grid grid-cols-2 gap-2 text-center text-slate-700 font-bold">
            <div className="border-r border-slate-200 py-0.5">
              <span className="block text-[9.5px] text-slate-400">이전 속도 산정</span>
              <span className="text-[13.5px] font-mono text-slate-800">{learningReport.previousSpeed} m/s</span>
            </div>
            <div className="py-0.5">
              <span className="block text-[9.5px] text-slate-400">학습 보정 속도</span>
              <span className="text-[13.5px] font-mono text-blue-600">{learningReport.newSpeed} m/s</span>
            </div>
          </div>
        )}

        <div className="flex items-center gap-2.5 pt-1 text-[11px] font-bold text-slate-500">
          <span>맞춤 보도 박자</span>
          <PaceBar speedFactor={learningReport ? learningReport.newSpeed / 1.0 : 0.7} />
          <span className="text-[9.5px] text-slate-400">표본: {learningReport?.samples}회</span>
        </div>
      </div>

      {/* Disclaimers & Action Controls */}
      <div className="space-y-4 pt-4">
        <div className="p-3 bg-blue-50 border border-blue-100 rounded-xl flex items-start gap-2.5 text-[11px] text-blue-700 leading-normal">
          <ShieldCheck className="w-4.5 h-4.5 shrink-0 mt-0.5" />
          <span>
            <b>개인정보 삭제 완료:</b> 세션 종료와 즉시 임시 GPS 캐시 정보가 소멸되었습니다. 계정 탈퇴나 로그아웃 시 로컬 토큰 또한 204 처리됩니다.
          </span>
        </div>

        <div className="space-y-2">
          <button
            onClick={() => {
              if (learningReport) {
                // Return updated profile back to app state
                onHome({
                  chars: [],
                  devices: [],
                  avoidStairs: false,
                  elevatorRequired: false,
                  lowFloorBusRequired: false,
                  avoidSteepSlopes: false,
                  walkingSpeedMps: learningReport.newSpeed,
                  walkingSpeedSource: "LEARNED",
                  walkingSpeedSampleCount: learningReport.samples
                });
              }
            }}
            className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white rounded-full font-bold text-[14px] shadow-sm transform active:scale-[0.98] transition-all flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Home className="w-4.5 h-4.5" />
            메인 화면으로 돌아가기
          </button>

          <button
            onClick={handleSignOut}
            className="w-full py-3 bg-white border border-slate-200 text-slate-600 hover:bg-slate-100 rounded-full font-bold text-[13.5px] flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <LogOut className="w-4.5 h-4.5" />
            로그아웃 후 종료
          </button>
        </div>
      </div>
    </div>
  );
}
