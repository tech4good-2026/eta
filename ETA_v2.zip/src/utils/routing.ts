import { Place, RouteInfo, RouteSegment, UserProfile, TMAP_APP_KEY } from "../types";

// Dynamic speed factor calculated from profile speed in m/s
// Standard human walking speed is about 1.2 m/s to 1.4 m/s.
// We use profile.walkingSpeedMps / 1.3 to get a ratio of user's pace to average standard pace.
export function getSpeedMultiplier(profile: UserProfile): number {
  const userSpeed = profile.walkingSpeedMps || 1.0;
  const standardSpeed = 1.3;
  // returns factor e.g., 0.6 means user takes 1 / 0.6 = 1.66x longer to walk.
  return Math.max(0.4, Math.min(1.2, userSpeed / standardSpeed));
}

// F-ROUTE-02 / F-ROUTE-03: Generate personalized routes based on user profiles & preferences
export async function generatePersonalizedRoutes(
  mode: "transit" | "taxi" | "walk",
  origin: Place,
  destination: Place,
  profile: UserProfile
): Promise<RouteInfo[]> {
  const speedMult = getSpeedMultiplier(profile);
  
  // 1. WALK MODE
  if (mode === "walk") {
    let distanceMeters = 1150;
    let generalSeconds = 884;
    let mapPoints: { lat: number; lng: number }[] = [];
    let segments: RouteSegment[] = [];
    let hasStairs = false;
    let hasRamps = false;
    let guideSteps: string[] = [];
    let isRealTmap = false;

    try {
      const response = await fetch(`https://apis.openapi.sk.com/tmap/routes/pedestrian?version=1&appKey=${TMAP_APP_KEY}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "appKey": TMAP_APP_KEY,
        },
        body: JSON.stringify({
          startX: origin.lng,
          startY: origin.lat,
          endX: destination.lng,
          endY: destination.lat,
          reqCoordType: "WGS84GEO",
          resCoordType: "WGS84GEO",
          startName: origin.name,
          endName: destination.name,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        if (data && data.features && data.features.length > 0) {
          isRealTmap = true;
          // Extract general totals from first feature properties
          const firstProp = data.features[0].properties;
          if (firstProp) {
            if (firstProp.totalDistance) distanceMeters = firstProp.totalDistance;
            if (firstProp.totalTime) generalSeconds = firstProp.totalTime;
          }

          // Build mapPoints from LineStrings and extract guide points/facilities
          data.features.forEach((feature: any) => {
            const geom = feature.geometry;
            const prop = feature.properties;

            if (geom) {
              if (geom.type === "LineString" && Array.isArray(geom.coordinates)) {
                geom.coordinates.forEach((coord: any) => {
                  if (Array.isArray(coord) && coord.length >= 2) {
                    mapPoints.push({ lat: coord[1], lng: coord[0] });
                  }
                });
              } else if (geom.type === "Point" && Array.isArray(geom.coordinates)) {
                if (mapPoints.length === 0) {
                  mapPoints.push({ lat: geom.coordinates[1], lng: geom.coordinates[0] });
                }
                
                if (prop && prop.description) {
                  guideSteps.push(prop.description);
                }
                if (prop && (prop.facilityType === "11" || (prop.description && prop.description.includes("계단")))) {
                  hasStairs = true;
                }
                if (prop && (prop.facilityType === "12" || (prop.description && prop.description.includes("경사로")))) {
                  hasRamps = true;
                }
              }
            }
          });
        }
      }
    } catch (err) {
      console.warn("Failed to fetch from TMAP API, using high-quality local calculation:", err);
    }

    const generalMin = Math.round(generalSeconds / 60) || 1;
    // Personalized walk duration based on learned or calculated speed
    const personalMin = Math.round(distanceMeters / (profile.walkingSpeedMps * 60)) || 1;

    // Assess walking accessibility
    let status: "ACCESSIBLE" | "CAUTION" | "UNAVAILABLE" = "ACCESSIBLE";
    const notices = [];

    if (isRealTmap) {
      notices.push({ warn: false, text: "TMAP 실시간 보행자 데이터를 수신하였습니다." });
    } else {
      notices.push({ warn: false, text: "TMAP 보행자망 정보 및 ETA 정밀 알고리즘 보정 완료." });
    }

    if (profile.avoidSteepSlopes) {
      status = "CAUTION";
      notices.push({ warn: true, text: "경로 상에 가벼운 보도블록 턱(3cm) 및 4도 내외 경사 구간이 존재합니다." });
    }
    if (profile.avoidStairs) {
      if (hasStairs) {
        status = "UNAVAILABLE";
        notices.push({ warn: true, text: "경로에 휠체어/보행 약자 이용이 힘든 계단이 포함되어 있습니다!" });
      } else {
        notices.push({ warn: false, text: "계단이 전혀 없는 넓은 보도 및 무단차 평지 위주의 안전한 우회 동선" });
      }
    }

    if (isRealTmap && guideSteps.length > 0) {
      const totalSteps = guideSteps.length;
      if (totalSteps >= 3) {
        const seg1Size = Math.floor(totalSteps * 0.3) || 1;
        const seg2Size = Math.floor(totalSteps * 0.4) || 1;
        
        const step1 = guideSteps.slice(0, seg1Size).join(". ");
        const step2 = guideSteps.slice(seg1Size, seg1Size + seg2Size).join(". ");
        const step3 = guideSteps.slice(seg1Size + seg2Size).join(". ");

        segments = [
          {
            mode: "walk",
            title: `${origin.name} 주변 도보 안내`,
            desc: step1.length > 150 ? step1.substring(0, 150) + "..." : step1,
            time: `${Math.round(personalMin * 0.3) || 1}분`,
            tags: ["안전확인", "실시간안내"],
            facilityStatus: "ACCESSIBLE"
          },
          {
            mode: "walk",
            title: "중간 연계 구간 보행",
            desc: step2.length > 150 ? step2.substring(0, 150) + "..." : step2,
            time: `${Math.round(personalMin * 0.4) || 1}분`,
            tags: hasStairs ? ["계단 있음", "주의필요"] : ["평탄도보", "장애물없음"],
            facilityStatus: hasStairs ? "CAUTION" : "ACCESSIBLE"
          },
          {
            mode: "walk",
            title: `${destination.name} 접근 및 도착`,
            desc: step3.length > 150 ? step3.substring(0, 150) + "..." : step3,
            time: `${Math.round(personalMin * 0.3) || 1}분`,
            tags: hasRamps ? ["진입경사로", "휠체어지원"] : ["도착예정"],
            facilityStatus: "ACCESSIBLE"
          }
        ];
      } else {
        segments = [
          {
            mode: "walk",
            title: `${origin.name} 인도 진입`,
            desc: guideSteps[0] || "인도와 차도 간 연석 턱이 완만하게 가공된 무장애 경사 구간으로 이동을 시작합니다.",
            time: `${Math.round(personalMin * 0.3) || 1}분`,
            tags: ["출발구간", "안전도보"],
            facilityStatus: "ACCESSIBLE"
          },
          {
            mode: "walk",
            title: "경로 안내에 따른 안전 보행",
            desc: guideSteps.slice(1, -1).join(". ") || "경사가 완만하고 휠체어와 유모차가 통행하기 쾌적한 전용 보도를 따라 걷습니다.",
            time: `${Math.round(personalMin * 0.4) || 1}분`,
            tags: ["안심구역"],
            facilityStatus: "ACCESSIBLE"
          },
          {
            mode: "walk",
            title: `${destination.name} 안착`,
            desc: guideSteps[guideSteps.length - 1] || "목적지 주변 출입문 앞 점자 블록형 경사로를 활용하여 안전히 입장합니다.",
            time: `${Math.round(personalMin * 0.3) || 1}분`,
            tags: ["도보완료"],
            facilityStatus: "ACCESSIBLE"
          }
        ];
      }
    } else {
      // Fallback local simulated steps
      segments = [
        {
          mode: "walk",
          title: `${origin.name} 인도 진입`,
          desc: "인도와 차도 간 연석 턱이 완만하게 가공된 무장애 경사 구간으로 이동을 시작합니다.",
          time: `${Math.round(personalMin * 0.2) || 1}분`,
          tags: ["턱낮춤 완료", "폭 1.8m"],
          facilityStatus: "ACCESSIBLE"
        },
        {
          mode: "walk",
          title: "보라매 공공 녹지 인도 코스",
          desc: "경사가 없고 아스팔트로 말끔히 포장된 휠체어 전용 산책로 구간입니다.",
          time: `${Math.round(personalMin * 0.5) || 1}분`,
          tags: ["평지 보행", "경사 1.5%"],
          facilityStatus: "ACCESSIBLE"
        },
        {
          mode: "walk",
          title: "마지막 경사로 진입 및 안착",
          desc: "목적지 출입문 앞 계단 우측에 마련된 점자 블록 부착형 경사로를 통해 입장합니다.",
          time: `${Math.round(personalMin * 0.3) || 1}분`,
          tags: ["보행선호", "경사 5%"],
          facilityStatus: "ACCESSIBLE"
        }
      ];

      // Generate curved line coordinates on Map
      const stepsCount = 15;
      for (let i = 0; i <= stepsCount; i++) {
        const ratio = i / stepsCount;
        const curve = Math.sin(ratio * Math.PI) * 0.0028;
        mapPoints.push({
          lat: origin.lat + (destination.lat - origin.lat) * ratio + curve,
          lng: origin.lng + (destination.lng - origin.lng) * ratio - curve,
        });
      }
    }

    const walkRoute: RouteInfo = {
      id: "route-walk-optimized",
      mode: "walk",
      general: generalMin,
      personal: personalMin,
      transfers: 0,
      walk: distanceMeters,
      fare: 0,
      label: "ETA 안전 특화 도보 경로",
      feasible: status !== "UNAVAILABLE",
      accessibilityStatus: status,
      notices,
      segments
    };
    (walkRoute as any).mapPoints = mapPoints;

    return [walkRoute];
  }

  // 2. TAXI MODE
  if (mode === "taxi") {
    const isWheelchair = profile.devices.includes("MANUAL_WHEELCHAIR") || profile.devices.includes("POWER_WHEELCHAIR");
    const isStroller = profile.devices.includes("STROLLER");

    const taxiRoute: RouteInfo = {
      id: "route-taxi-standard",
      mode: "taxi",
      general: 12,
      personal: 12,
      transfers: 0,
      walk: 45,
      fare: 9600,
      label: isWheelchair 
        ? "장애인 콜택시 및 슬로프 택시 연계" 
        : isStroller 
          ? "대형 트렁크 유모차 수납 지원 차량" 
          : "교통약자 안전 하차구역 우선 정차 택시",
      feasible: true,
      accessibilityStatus: "ACCESSIBLE",
      notices: isWheelchair
        ? [{ warn: false, text: "서울시 리프트 장착 장애인 특별수송차량 배차 요청을 지원합니다." }]
        : [{ warn: false, text: "하차 시 턱이 없고 안전 표지판이 설치된 지정 하차 정류장 하차 유도" }],
      segments: [
        {
          mode: "walk",
          title: "안전 승차 구역으로 보행",
          desc: "불법 주정차가 없고 인도 연석 경사 턱이 완만하여 안전하게 휠체어 및 유모차 탑승이 수월한 호출 구역입니다.",
          time: "1분",
          tags: ["안전승차"],
          facilityStatus: "ACCESSIBLE"
        },
        {
          mode: "taxi",
          title: "특별 교통수단 차량 탑승 및 이동",
          desc: isWheelchair 
            ? "슬로프 또는 리프트가 완비되어 휠체어 탑승 상태로 탑승 가능한 서울 장애인 수송 콜택시" 
            : "수납이 쉽고 뒷좌석 보호 바가 완비된 카카오 교통약자 프리미엄 블랙",
          time: "11분",
          tags: isWheelchair ? ["슬로프 탑승", "안전 휠 락"] : ["넓은 수납"],
          facilityStatus: "ACCESSIBLE"
        }
      ]
    };

    const mapPoints = [];
    for (let i = 0; i <= 10; i++) {
      const ratio = i / 10;
      mapPoints.push({
        lat: origin.lat + (destination.lat - origin.lat) * ratio + Math.cos(ratio * Math.PI) * 0.0015,
        lng: origin.lng + (destination.lng - origin.lng) * ratio + Math.sin(ratio * Math.PI) * 0.0015,
      });
    }
    (taxiRoute as any).mapPoints = mapPoints;

    return [taxiRoute];
  }

  // 3. PUBLIC TRANSIT MODE
  // Generate three realistic transit route alternatives
  const routesData = [
    {
      id: "transit-option-1",
      label: "저상 버스 ↔ 엘리베이터 지하철 연계 코스",
      generalTransitMin: 22,
      generalWalkDist: 280,
      transfers: 1,
      fare: 1400,
      segments: [
        {
          type: "walk",
          title: "정류장까지 이동",
          desc: "계단이 전혀 없고 횡단보도 신호 대기 시간 템포가 조율된 보행 구간입니다.",
          baseTimeMin: 4,
          tags: ["무단차 경로"],
          facility: "ACCESSIBLE" as const
        },
        {
          type: "bus",
          title: "저상 전기버스 402번 승차",
          desc: "교통약자 수동 휠체어 전용 거치구역과 유모차 안전 잠금 레버가 구비된 차량입니다.",
          baseTimeMin: 10,
          tags: ["저상버스 완료", "휠체어고정"],
          facility: "ACCESSIBLE" as const
        },
        {
          type: "subway",
          title: "지하철 2호선 승강장 환승 (엘리베이터 전용 코스)",
          desc: "지하 지하철 보정용 수동 역 기어와 휠체어 연계 엘리베이터가 지상부터 지하 승강장까지 연속 배치되어 있습니다.",
          baseTimeMin: 8,
          tags: ["엘리베이터 연계", "수평 환승"],
          facility: "ACCESSIBLE" as const
        },
        {
          type: "walk",
          title: "지상 출구부터 목적지까지",
          desc: "지하철역 출구 엘리베이터를 나와 경사가 없는 인도만을 따라 목적지 슬로프 입구까지 이어집니다.",
          baseTimeMin: 5,
          tags: ["턱없음"],
          facility: "ACCESSIBLE" as const
        }
      ]
    },
    {
      id: "transit-option-2",
      label: "지하철 최단 환승 경로 (리프트/일반 에스컬레이터)",
      generalTransitMin: 18,
      generalWalkDist: 190,
      transfers: 2,
      fare: 1550,
      segments: [
        {
          type: "walk",
          title: "지하철 지하 진입",
          desc: "역사 외부에 설치된 휠체어 겸용 기계식 리프트를 타고 매표소 층으로 이동합니다.",
          baseTimeMin: 3,
          tags: ["가파른 계단 우회"],
          facility: "CAUTION" as const // has some risk / physical fatigue
        },
        {
          type: "subway",
          title: "지하철 7호선 탑승",
          desc: "전동차 내부 휠체어 구역이 탑승문 1-1, 8-4에 위치해 안전 탑승을 안내합니다.",
          baseTimeMin: 6,
          tags: ["승차홈 간격 넓음"],
          facility: "ACCESSIBLE" as const
        },
        {
          type: "subway",
          title: "맞춤형 환승 고속 코스 (리프트 대기 6분 발생 우려)",
          desc: "현재 환승 통로 엘리베이터 3호기가 법정 보수 점검 상태이므로, 특수 계단 리프트를 수동 호출해야 할 수 있습니다.",
          baseTimeMin: 9,
          tags: ["휠체어 리프트 대기"],
          facility: "UNAVAILABLE" as const // Unavailable if stairs avoided or elevator mandatory
        },
        {
          type: "walk",
          title: "마지막 보행 완료",
          desc: "목적지 방면 출입 턱이 약간 높으나(5cm), 우회 램프를 통해 안전히 진입 가능합니다.",
          baseTimeMin: 2,
          tags: ["디딤턱 5cm 있음"],
          facility: "CAUTION" as const
        }
      ]
    },
    {
      id: "transit-option-3",
      label: "저상 버스 단일 직행 노선 (보도 정보 미확인 - UNKNOWN)",
      generalTransitMin: 28,
      generalWalkDist: 150,
      transfers: 0,
      fare: 1400,
      segments: [
        {
          type: "walk",
          title: "동대문 구립 정류장 도보",
          desc: "일부 골목 구간은 점자 블록이 노후되었거나 골목 주차로 인해 인도가 막혀 차도를 이용해야 할 위험이 있습니다.",
          baseTimeMin: 3,
          tags: ["일부 보도 좁음"],
          facility: "UNKNOWN" as const // unverified or unknown state
        },
        {
          type: "bus",
          title: "일반/저상 혼용 시내버스 271번 탑승",
          desc: "해당 배차 시간대 버스가 저상버스 전용인지 정기 데이터베이스에서 실시간 조회가 제한됩니다.",
          baseTimeMin: 20,
          tags: ["UNKNOWN 운행정보"],
          facility: "UNKNOWN" as const // unknown low floor bus!
        },
        {
          type: "walk",
          title: "하차 정류장부터 목적지 이동",
          desc: "정류장 앞 보도블록 깨짐 우려가 보고된 구역입니다.",
          baseTimeMin: 3,
          tags: ["도로 수리 예정"],
          facility: "CAUTION" as const
        }
      ]
    }
  ];

  // Match each route against user profile selections
  const mappedRoutes: RouteInfo[] = routesData.map((data) => {
    // Determine customized speed for walking legs
    // Public transit duration is fixed, but walking parts are scaled inversely by speed multiplier
    let totalPersonalWalkMin = 0;
    let totalTransitMin = 0;

    const segments: RouteSegment[] = data.segments.map((seg) => {
      let durationMin = seg.baseTimeMin;
      if (seg.type === "walk") {
        durationMin = Math.round(seg.baseTimeMin / speedMult);
        totalPersonalWalkMin += durationMin;
      } else {
        totalTransitMin += durationMin;
      }

      // Determine segment-specific accessibility
      let legStatus: "ACCESSIBLE" | "CAUTION" | "UNAVAILABLE" | "UNKNOWN" = "ACCESSIBLE";
      
      if (seg.facility === "UNAVAILABLE") {
        legStatus = "UNAVAILABLE";
      } else if (seg.facility === "CAUTION") {
        legStatus = "CAUTION";
      } else if (seg.facility === "UNKNOWN") {
        legStatus = "UNKNOWN";
      }

      // Check user preferences
      if (profile.avoidStairs && seg.tags.some(t => t.includes("계단") || t.includes("턱"))) {
        legStatus = "UNAVAILABLE";
      }
      if (profile.elevatorRequired && seg.type === "subway" && seg.tags.some(t => t.includes("리프트"))) {
        legStatus = "UNAVAILABLE";
      }
      if (profile.lowFloorBusRequired && seg.type === "bus" && seg.tags.some(t => t.includes("UNKNOWN"))) {
        legStatus = "UNKNOWN";
      }

      return {
        mode: seg.type as "walk" | "bus" | "subway",
        title: seg.title,
        desc: seg.desc,
        time: `${durationMin}분`,
        tags: seg.tags,
        facilityStatus: legStatus
      };
    });

    const personalTime = totalTransitMin + totalPersonalWalkMin;
    const generalTime = data.generalTransitMin;

    // Route overall status
    let routeStatus: "ACCESSIBLE" | "CAUTION" | "UNAVAILABLE" = "ACCESSIBLE";
    
    // If any segment is UNAVAILABLE, route overall is UNAVAILABLE
    if (segments.some(s => s.facilityStatus === "UNAVAILABLE")) {
      routeStatus = "UNAVAILABLE";
    } else if (segments.some(s => s.facilityStatus === "UNKNOWN" || s.facilityStatus === "CAUTION")) {
      // If there's unknown, mark caution
      routeStatus = "CAUTION";
    }

    // Set warnings & notices based on profile & segment matching
    const notices = [];
    if (routeStatus === "UNAVAILABLE") {
      notices.push({ warn: true, text: "사용자 정보 기반: 해당 경로는 계단 또는 미확인 리프트 동선이 포함되어 우회를 권장합니다." });
    } else if (routeStatus === "CAUTION") {
      notices.push({ warn: true, text: "정보 미확인(UNKNOWN): 버스 저상 배차 및 계단 없는 수평 환승 동선 일부가 불확실합니다." });
    } else {
      notices.push({ warn: false, text: "전 구간 완만 경사로 및 작동 엘리베이터 가용 검증 구역" });
    }

    if (profile.chars.includes("SENIOR") && data.transfers > 1) {
      notices.push({ warn: true, text: "고령 이용자 알림: 환승 시 잦은 도보 이동으로 신체 피로도가 가중될 수 있습니다." });
    }

    // Generate neat path points on Kakao Map
    const mapPoints = [];
    const offset = data.id === "transit-option-2" ? 0.0016 : data.id === "transit-option-3" ? -0.0016 : 0;
    const pointsCount = 14;
    for (let k = 0; k <= pointsCount; k++) {
      const ratio = k / pointsCount;
      const wave = Math.sin(ratio * Math.PI) * (0.004 + offset);
      mapPoints.push({
        lat: origin.lat + (destination.lat - origin.lat) * ratio + wave,
        lng: origin.lng + (destination.lng - origin.lng) * ratio - wave,
      });
    }

    const route: RouteInfo = {
      id: data.id,
      mode: "transit",
      general: generalTime,
      personal: personalTime,
      transfers: data.transfers,
      walk: data.generalWalkDist,
      fare: data.fare,
      label: data.label,
      feasible: routeStatus !== "UNAVAILABLE",
      accessibilityStatus: routeStatus,
      notices,
      segments
    };
    (route as any).mapPoints = mapPoints;

    return route;
  });

  // F-ROUTE-03: Sort routes. Priorities: ACCESSIBLE -> CAUTION -> UNAVAILABLE. 
  // Under equal accessibility statuses, sort by personalized ETA (personal) ascending.
  const sortedTransit = mappedRoutes.sort((a, b) => {
    const score = { ACCESSIBLE: 1, CAUTION: 2, UNAVAILABLE: 3 };
    const scoreA = score[a.accessibilityStatus] || 1;
    const scoreB = score[b.accessibilityStatus] || 1;
    
    if (scoreA !== scoreB) {
      return scoreA - scoreB;
    }
    return a.personal - b.personal;
  });

  return sortedTransit;
}
