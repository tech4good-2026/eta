import { UserProfile } from "../types";

const USERS_KEY = "eta_users_db";
const SESSION_KEY = "eta_session_jwt";

// Initial profile helper
export const DEFAULT_PROFILE: UserProfile = {
  chars: ["MOBILITY_IMPAIRED"],
  devices: ["MANUAL_WHEELCHAIR"],
  avoidStairs: true,
  elevatorRequired: true,
  lowFloorBusRequired: true,
  avoidSteepSlopes: true,
  walkingSpeedMps: 0.70,
  walkingSpeedSource: "CALCULATED",
  walkingSpeedSampleCount: 0,
};

export interface UserAccount {
  email: string;
  passwordHash: string; // we'll just store plaintext password for simulation
  profile: UserProfile;
  profileCompleted: boolean;
}

// Seed mock database with a default user if empty
export function initAuthDb() {
  if (typeof window === "undefined") return;
  const existing = localStorage.getItem(USERS_KEY);
  if (!existing) {
    const defaultUser: UserAccount = {
      email: "test@eta.com",
      passwordHash: "password123",
      profile: { ...DEFAULT_PROFILE },
      profileCompleted: true,
    };
    localStorage.setItem(USERS_KEY, JSON.stringify([defaultUser]));
  }
}

// Get all users
function getUsers(): UserAccount[] {
  initAuthDb();
  const raw = localStorage.getItem(USERS_KEY);
  return raw ? JSON.parse(raw) : [];
}

// Save users
function saveUsers(users: UserAccount[]) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

// F-AUTH-01: Sign Up
export function signUpUser(email: string, password: string): { token: string; profileCompleted: boolean; user: UserAccount } {
  if (password.length < 8) {
    throw new Error("비밀번호는 최소 8자 이상이어야 합니다.");
  }

  const users = getUsers();
  const exists = users.some((u) => u.email.toLowerCase() === email.toLowerCase());
  if (exists) {
    throw new Error("409 EMAIL_ALREADY_EXISTS");
  }

  const newUser: UserAccount = {
    email: email.toLowerCase(),
    passwordHash: password,
    profile: {
      chars: [],
      devices: [],
      avoidStairs: false,
      elevatorRequired: false,
      lowFloorBusRequired: false,
      avoidSteepSlopes: false,
      walkingSpeedMps: 1.0,
      walkingSpeedSource: "CALCULATED",
      walkingSpeedSampleCount: 0,
    },
    profileCompleted: false,
  };

  users.push(newUser);
  saveUsers(users);

  // Generate simulated JWT
  const token = `eta-jwt-header.${btoa(JSON.stringify({ email: newUser.email }))}.signature`;
  localStorage.setItem(SESSION_KEY, JSON.stringify({ token, email: newUser.email }));

  return { token, profileCompleted: false, user: newUser };
}

// F-AUTH-02: Sign In
export function signInUser(email: string, password: string): { token: string; profileCompleted: boolean; user: UserAccount } {
  const users = getUsers();
  const user = users.find(
    (u) => u.email.toLowerCase() === email.toLowerCase() && u.passwordHash === password
  );

  if (!user) {
    throw new Error("401 INVALID_CREDENTIALS");
  }

  const token = `eta-jwt-header.${btoa(JSON.stringify({ email: user.email }))}.signature`;
  localStorage.setItem(SESSION_KEY, JSON.stringify({ token, email: user.email }));

  return { token, profileCompleted: user.profileCompleted, user };
}

// F-AUTH-03: Sign Out
export function signOutUser() {
  localStorage.removeItem(SESSION_KEY);
}

// F-AUTH-04: Delete Account
export function deleteUserAccount(email: string) {
  const users = getUsers();
  const filtered = users.filter((u) => u.email.toLowerCase() !== email.toLowerCase());
  saveUsers(filtered);
  signOutUser();
}

// Get logged-in session
export function getActiveSession(): { email: string; user: UserAccount } | null {
  const rawSession = localStorage.getItem(SESSION_KEY);
  if (!rawSession) return null;
  try {
    const { email } = JSON.parse(rawSession);
    const users = getUsers();
    const user = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (user) {
      return { email, user };
    }
  } catch (e) {
    signOutUser();
  }
  return null;
}

// Calculate initial walking speed based on traveler features (Section 3 of Spec)
export function calculateInitialSpeed(chars: string[], devices: string[]): number {
  let speed = 1.0; // Base speed m/s
  
  if (devices.includes("MANUAL_WHEELCHAIR")) speed = Math.min(speed, 0.70);
  if (devices.includes("POWER_WHEELCHAIR")) speed = Math.min(speed, 0.75);
  if (devices.includes("STROLLER")) speed = Math.min(speed, 0.85);
  if (devices.includes("CANE")) speed = Math.min(speed, 0.80);
  if (devices.includes("CRUTCHES")) speed = Math.min(speed, 0.75);
  if (devices.includes("WALKER")) speed = Math.min(speed, 0.72);
  
  if (chars.includes("SENIOR")) speed = Math.min(speed, 0.85);
  if (chars.includes("PREGNANT")) speed = Math.min(speed, 0.90);
  if (chars.includes("TEMPORARILY_INJURED")) speed = Math.min(speed, 0.80);
  if (chars.includes("MOBILITY_IMPAIRED")) speed = Math.min(speed, 0.70);

  return parseFloat(speed.toFixed(2));
}

// F-PROFILE-01 / 02: Save Profile
export function updateUserProfile(email: string, profileData: Partial<UserProfile>): UserAccount {
  const users = getUsers();
  const userIdx = users.findIndex((u) => u.email.toLowerCase() === email.toLowerCase());
  if (userIdx === -1) throw new Error("사용자를 찾을 수 없습니다.");

  const currentProfile = users[userIdx].profile;
  const nextProfile = { ...currentProfile, ...profileData };

  // Re-calculate initial walking speed if speed wasn't learned yet or if chars/devices changed
  if (profileData.chars || profileData.devices) {
    const chars = profileData.chars || currentProfile.chars;
    const devices = profileData.devices || currentProfile.devices;
    
    // Only reset speed if not already learned
    if (currentProfile.walkingSpeedSource !== "LEARNED") {
      nextProfile.walkingSpeedMps = calculateInitialSpeed(chars, devices);
    }
  }

  users[userIdx].profile = nextProfile;
  users[userIdx].profileCompleted = true;
  saveUsers(users);
  return users[userIdx];
}

// F-PROFILE-03: Self-learning Speed (Update speed stats on trip complete)
export function learnWalkingSpeed(email: string, observedSpeedMps: number): UserAccount {
  const users = getUsers();
  const userIdx = users.findIndex((u) => u.email.toLowerCase() === email.toLowerCase());
  if (userIdx === -1) throw new Error("사용자를 찾을 수 없습니다.");

  const profile = users[userIdx].profile;
  const count = profile.walkingSpeedSampleCount + 1;
  
  // Calculate rolling moving average: (previous_speed * prev_count + new_speed) / new_count
  const currentSpeed = profile.walkingSpeedMps;
  const newAverage = (currentSpeed * profile.walkingSpeedSampleCount + observedSpeedMps) / count;

  profile.walkingSpeedMps = parseFloat(newAverage.toFixed(2));
  profile.walkingSpeedSource = "LEARNED";
  profile.walkingSpeedSampleCount = count;

  users[userIdx].profile = profile;
  saveUsers(users);
  return users[userIdx];
}
