/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface UserProfile {
  chars: string[]; // TravelerType codes: PREGNANT, SENIOR, MOBILITY_IMPAIRED, TEMPORARILY_INJURED, CAREGIVER_WITH_CHILD, OTHER
  devices: string[]; // MobilityAid codes: MANUAL_WHEELCHAIR, POWER_WHEELCHAIR, STROLLER, CANE, CRUTCHES, WALKER, NONE
  avoidStairs: boolean;
  elevatorRequired: boolean;
  lowFloorBusRequired: boolean;
  avoidSteepSlopes: boolean;
  walkingSpeedMps: number;
  walkingSpeedSource: "CALCULATED" | "LEARNED";
  walkingSpeedSampleCount: number;
}

export interface Place {
  id: string;
  name: string;
  addr: string;
  tag: string;
  lat: number;
  lng: number;
  category: string;
  phone: string;
  placeUrl: string;
}

export interface RouteSegment {
  mode: "walk" | "bus" | "subway" | "taxi";
  title: string;
  desc: string;
  time: string;
  tags?: string[];
  facilityStatus?: "ACCESSIBLE" | "CAUTION" | "UNAVAILABLE" | "UNKNOWN";
}

export interface RouteNotice {
  warn: boolean;
  text: string;
}

export interface RouteInfo {
  id: string;
  mode: "transit" | "taxi" | "walk";
  general: number; // general duration in minutes
  personal: number; // custom duration in minutes
  transfers: number;
  walk: number; // walk distance in meters
  fare: number;
  label: string;
  feasible: boolean;
  accessibilityStatus: "ACCESSIBLE" | "CAUTION" | "UNAVAILABLE";
  notices: RouteNotice[];
  segments: RouteSegment[];
}

export const CHAR_OPTIONS = [
  { code: "PREGNANT", label: "임산부" },
  { code: "SENIOR", label: "고령자" },
  { code: "MOBILITY_IMPAIRED", label: "지체·이동 제약 사용자" },
  { code: "TEMPORARILY_INJURED", label: "일시적 부상자" },
  { code: "CAREGIVER_WITH_CHILD", label: "영유아 동반자" },
  { code: "OTHER", label: "기타" }
];

export const DEVICE_OPTIONS = [
  { code: "MANUAL_WHEELCHAIR", label: "수동 휠체어" },
  { code: "POWER_WHEELCHAIR", label: "전동 휠체어" },
  { code: "STROLLER", label: "유모차" },
  { code: "CANE", label: "지팡이" },
  { code: "CRUTCHES", label: "목발" },
  { code: "WALKER", label: "보행 보조기" },
  { code: "NONE", label: "없음" }
];

export const PLACES: Place[] = [
  { id: "p1", name: "국립중앙도서관", addr: "서울 서초구 반포대로 201", tag: "엘리베이터 확인됨", lat: 37.4980, lng: 127.0245, category: "도서관", phone: "02-535-4142", placeUrl: "https://www.nl.go.kr" },
  { id: "p2", name: "서울역", addr: "서울 용산구 한강대로 405", tag: "저상버스 정류장 인접", lat: 37.5547, lng: 126.9707, category: "기차역", phone: "1544-7788", placeUrl: "https://www.letskorail.com" },
  { id: "p3", name: "보라매공원", addr: "서울 동작구 여의대방로 20길", tag: "경사로 있음", lat: 37.4923, lng: 126.9227, category: "공원", phone: "02-2181-1190", placeUrl: "https://parks.seoul.go.kr" },
  { id: "p4", name: "강남세브란스병원", addr: "서울 강남구 언주로 211", tag: "휠체어 접근로 확인됨", lat: 37.4924, lng: 127.0463, category: "의료기관", phone: "1599-6114", placeUrl: "https://gs.yuhs.ac" },
  { id: "p5", name: "홍대입구역 2번 출구", addr: "서울 마포구 양화로 160", tag: "엘리베이터 확인됨", lat: 37.5572, lng: 126.9245, category: "지하철역", phone: "02-6110-2391", placeUrl: "http://www.seoulmetro.co.kr" },
  { id: "p6", name: "롯데월드타워", addr: "서울 송파구 올림픽로 300", tag: "휠체어 접근로 확인됨", lat: 37.5125, lng: 127.1025, category: "복합쇼핑몰", phone: "02-3213-5000", placeUrl: "https://www.lotteworldtower.com" }
];

export const TMAP_APP_KEY = "flqzyKevpJ8B3F92YJnpK4HNjpju2y46aryjxd4R";
export const TMAP_PEDESTRIAN_URL = "https://apis.openapi.sk.com/tmap/routes/pedestrian?version=1";
