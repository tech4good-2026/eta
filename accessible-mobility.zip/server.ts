import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.post('/api/chat', async (req, res) => {
    try {
      const { messages } = req.body;
      
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ error: 'GEMINI_API_KEY is missing' });
      }

      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      const contents = messages.map((msg: any) => ({
        role: msg.role === 'user' ? 'user' : 'model',
        parts: [{ text: msg.content }],
      }));

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents,
        config: {
          systemInstruction: 'You are a helpful mobility assistant for transportation-vulnerable individuals (elderly, disabled, pregnant women). Provide concise, empathetic, and clear guidance regarding accessible routing and transportation options.',
        }
      });

      res.json({ text: response.text });
    } catch (error: any) {
      console.error('Chat error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/route', async (req, res) => {
    const { origin, destination, profile } = req.body;
    
    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ error: 'GEMINI_API_KEY is missing' });
      }

      const userSpeedKmh = profile?.walkSpeed || 2.5;
      const userSpeedMs = (userSpeedKmh * 1000 / 3600).toFixed(2);
      
      const prompt = `
너는 교통약자(고령자, 휠체어 이용자 등)를 위한 초개인화 이동 내비게이션의 핵심 추론 엔진이야. 
tmap의 api키를 받아서 사용해봐.94XQ5ZS64g6XsvHTvdDEJ5e47j6HThxK1Hw84Mi3

일반적인 보행 속도를 무시하고, 사용자의 고유한 속도와 지형적 특성, 실시간 버스 정보를 종합하여 가장 현실적인 이동 솔루션을 JSON 형태로 제공해야 해.

[핵심 목표]
1. 입력된 Tmap 거리를 사용자의 캘리브레이션 속도를 바탕으로 실제 소요 시간(분)으로 변환해.
2. Tmap 경로상에 '계단'이 포함되어 있으면 해당 경로는 '휠체어 이동 불가'로 판정하고, 오르막/내리막/지하도 등의 제약 사항이 있으면 소요 시간에 1.2배의 가중치를 부여해.
3. 계산된 도착 시간과 버스 도착 시간을 비교하여 버스 탑승 가능 여부를 판단해.
4. 버스 탑승이 불가능할 경우, 장애인 콜택시 대기 시간 및 일반 택시 비용 등을 고려하여 최적의 대안을 추천해.

[수식 규칙]
- 기본 소요 시간(초) = 총 거리(m) / 사용자 속도(m/s)
- 최종 소요 시간(분) = 기본 소요 시간(초) / 60 (반올림하여 정수 표기)

[입력 데이터]
User_Speed: ${userSpeedMs} (m/s)
User_Type: ${profile?.userType === 'disabled' ? '휠체어 이용자' : '고령자/임산부'}
TMAP_Distance: 800 (m) (가상의 출발-정류장 거리)
TMAP_Obstacles: ["약한 오르막", "횡단보도"]
Bus_Status: {"target_bus": "143번", "arrival_time_min": 15, "next_bus_min": 35}
Alternative_Info: {"call_taxi_wait_min": 25, "normal_taxi_cost": 8500}
Origin: ${origin}
Destination: ${destination}

위 입력 데이터를 바탕으로 다음 포맷의 엄격한 JSON을 생성해:
{
  "calculated_time_min": 숫자,
  "is_bus_catchable": boolean,
  "obstacle_warning": "문자열",
  "recommended_action": "문자열",
  "alternative_suggestion": "문자열",
  "bus_arrival_time": 숫자
}
`;

      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      let engineResult;
      
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
          }
        });
        
        engineResult = JSON.parse(response.text!);
      } catch (aiError: any) {
        console.warn('AI inference failed, using fallback engine logic:', aiError.message);
        
        const calcTime = Math.round(800 / Number(userSpeedMs) / 60);
        engineResult = {
          calculated_time_min: calcTime,
          is_bus_catchable: calcTime <= 15,
          obstacle_warning: profile?.userType === 'disabled' ? "휠체어 이동 시 주의: 약한 오르막 구간 및 횡단보도가 있습니다." : "약한 오르막 구간 및 횡단보도가 있습니다.",
          recommended_action: calcTime <= 15 ? "목표 저상버스 탑승이 가능할 것으로 예상됩니다." : "목표 저상버스(15분 후) 탑승이 어려울 수 있습니다. 다음 버스(35분 후)를 권장합니다.",
          alternative_suggestion: "장애인 콜택시는 예상 대기 시간이 25분입니다. 빠른 이동이 필요하다면 일반 택시(약 8,500원) 이용을 고려하세요.",
          bus_arrival_time: 15
        };
      }
      
      // Build the UI route data based on engine reasoning
      const walkTime = engineResult.calculated_time_min;
      const canCatchBus = engineResult.is_bus_catchable;
      const busWaitTime = canCatchBus ? Math.max(0, engineResult.bus_arrival_time - walkTime) : 0;
      
      const publicTransitTime = walkTime + busWaitTime + 20; // 20m bus ride
      
      const routeData = {
        summary: `${origin}에서 ${destination}까지`,
        routes: [
          {
            id: 'route-1',
            type: 'public_transit',
            label: canCatchBus ? '저상버스 143번 탑승 추천' : '저상버스 탑승 지연 (다음 버스 권장)',
            estimatedTimeMinutes: canCatchBus ? publicTransitTime : (walkTime + 35 + 20),
            baseEstimatedTime: 45,
            cost: '1,400원',
            steps: [
              { instruction: '정류장까지 맞춤 보행 이동', time: walkTime, type: 'walk', warnings: engineResult.obstacle_warning ? [engineResult.obstacle_warning] : [] },
              { instruction: '143번 저상버스 탑승', time: 20, type: 'bus', info: engineResult.recommended_action },
              { instruction: '목적지까지 이동', time: 5, type: 'walk' }
            ]
          },
          {
            id: 'route-2',
            type: 'call_taxi',
            label: '장애인 콜택시 대안',
            estimatedTimeMinutes: 25 + 20, // Wait 25 + ride 20
            baseEstimatedTime: 45,
            cost: '2,400원',
            steps: [
              { instruction: '차량 배차 대기', time: 25, type: 'wait', info: '예상 대기 25분' },
              { instruction: '택시 탑승 후 이동', time: 20, type: 'taxi', info: engineResult.alternative_suggestion }
            ]
          },
          {
            id: 'route-3',
            type: 'walk',
            label: '전체 도보 이동',
            estimatedTimeMinutes: Math.round(2000 / Number(userSpeedMs) / 60), // Mock 2km full walk
            baseEstimatedTime: 40,
            cost: '0원',
            steps: [
              { instruction: '안전 보행로를 따라 이동', time: Math.round(2000 / Number(userSpeedMs) / 60), type: 'walk', info: '휠체어 접근 가능 보행로 활용' }
            ]
          }
        ]
      };
      
      res.json(routeData);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Failed to calculate route' });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch(console.error);
