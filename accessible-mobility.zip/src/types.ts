export interface UserProfile {
  email: string;
  userType: 'elderly' | 'disabled' | 'pregnant' | 'infant' | 'none';
  walkSpeed: number; // km/h
}

export interface RouteStep {
  instruction: string;
  time: number;
  type: 'walk' | 'bus' | 'subway' | 'taxi' | 'wait';
  warnings?: string[];
  info?: string;
}

export interface RouteOption {
  id: string;
  type: string;
  label: string;
  estimatedTimeMinutes: number;
  baseEstimatedTime: number;
  steps: RouteStep[];
}

export interface RouteData {
  summary: string;
  routes: RouteOption[];
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
}
