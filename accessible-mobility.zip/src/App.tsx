import React, { useState } from 'react';
import { Onboarding } from './components/Onboarding';
import { MainMap } from './components/MainMap';
import { RouteSearch } from './components/RouteSearch';
import { RouteResult } from './components/RouteResult';
import { Chatbot } from './components/Chatbot';
import { UserProfile, RouteData } from './types';
import { MessageCircle } from 'lucide-react';

type Screen = 'onboarding' | 'map' | 'search' | 'result';

export default function App() {
  const [screen, setScreen] = useState<Screen>('onboarding');
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [routeData, setRouteData] = useState<RouteData | null>(null);
  const [showChat, setShowChat] = useState(false);

  const handleOnboardingComplete = (p: UserProfile) => {
    setProfile(p);
    setScreen('map');
  };

  const handleSearchRoute = async (origin: string, destination: string) => {
    try {
      const response = await fetch('/api/route', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ origin, destination, profile }),
      });
      const data = await response.json();
      if (data.routes) {
        setRouteData(data);
        setScreen('result');
      } else {
        alert('경로 검색 중 오류가 발생했습니다: ' + (data.error || '알 수 없는 오류'));
      }
    } catch (e) {
      console.error(e);
      alert('경로 검색 중 오류가 발생했습니다.');
    }
  };

  return (
    <div className="w-full max-w-md mx-auto h-screen bg-slate-50 text-slate-900 relative overflow-hidden flex flex-col font-sans">
      {/* Screens */}
      {screen === 'onboarding' && <Onboarding onComplete={handleOnboardingComplete} />}
      {screen === 'map' && <MainMap onSearchClick={() => setScreen('search')} />}
      {screen === 'search' && (
        <RouteSearch 
          onBack={() => setScreen('map')} 
          onSearch={handleSearchRoute} 
        />
      )}
      {screen === 'result' && routeData && profile && (
        <RouteResult 
          onBack={() => setScreen('search')}
          routeData={routeData}
          profile={profile}
        />
      )}

      {/* FAB for Chat */}
      {screen !== 'onboarding' && !showChat && (
        <button
          onClick={() => setShowChat(true)}
          className="absolute bottom-6 right-6 px-4 h-14 bg-slate-900 hover:bg-slate-800 text-white rounded-full shadow-xl flex items-center justify-center gap-2 transition-transform hover:scale-105 active:scale-95 border border-slate-700"
        >
          <MessageCircle className="w-5 h-5" />
          <span className="font-bold text-sm tracking-wide">Ask AI</span>
        </button>
      )}

      {/* Chat Overlay */}
      {showChat && (
        <div className="absolute inset-0 z-50 bg-black/50 sm:p-4 p-0 flex items-end sm:items-center justify-center">
          <div className="w-full h-[85vh] sm:h-[600px] sm:rounded-3xl sm:max-w-md w-full relative">
            <Chatbot onClose={() => setShowChat(false)} />
          </div>
        </div>
      )}
    </div>
  );
}
