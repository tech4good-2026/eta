import React, { useState } from 'react';
import { ArrowLeft, Bus, Car, Footprints, Clock, AlertTriangle, Accessibility, Train } from 'lucide-react';
import { RouteData, UserProfile } from '../types';

interface RouteResultProps {
  onBack: () => void;
  routeData: RouteData;
  profile: UserProfile;
}

export function RouteResult({ onBack, routeData, profile }: RouteResultProps) {
  const [selectedType, setSelectedType] = useState('all');

  const filteredRoutes = (routeData?.routes || []).filter(r => 
    selectedType === 'all' ? true : r.type === selectedType
  );

  return (
    <div className="flex flex-col h-full bg-slate-50 text-slate-900 overflow-hidden">
      {/* Header */}
      <div className="bg-white px-4 pt-4 pb-2 border-b border-slate-200 shadow-[0_2px_8px_rgba(0,0,0,0.05)] z-10 shrink-0">
        <div className="flex items-center gap-3 mb-2">
          <button onClick={onBack} className="p-2 -ml-2 text-slate-600 hover:bg-slate-50 rounded-full transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="flex-1 overflow-hidden whitespace-nowrap text-ellipsis font-extrabold text-lg tracking-tight text-slate-800">
            {routeData.summary}
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 w-full mt-2 overflow-x-auto hide-scrollbar pb-1">
          {[
            { id: 'all', label: '전체' },
            { id: 'public_transit', label: '대중교통' },
            { id: 'call_taxi', label: '택시' },
            { id: 'walk', label: '도보' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setSelectedType(tab.id)}
              className={`px-4 py-2 rounded-full font-bold text-sm whitespace-nowrap transition-colors border ${
                selectedType === tab.id 
                  ? 'bg-slate-800 text-white border-slate-800 shadow-sm' 
                  : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {/* Profile Notice */}
        <div className="p-4 m-4 bg-blue-50 border border-blue-100 rounded-2xl flex flex-col shadow-sm">
          <div className="flex justify-between items-center mb-3">
            <h3 className="text-sm font-extrabold text-blue-900 flex items-center gap-2">
              <Accessibility className="w-5 h-5 text-blue-600" />
              내 보행 페이스 적용됨
            </h3>
            <span className="px-2 py-0.5 bg-blue-600 text-white text-[10px] rounded uppercase font-bold tracking-widest shadow-sm">Verified</span>
          </div>
          <div className="text-3xl font-black text-blue-900">{profile.walkSpeed} <span className="text-base font-bold text-blue-700">km/h</span></div>
          <p className="text-xs text-blue-600 mt-2 font-medium">
            설정된 보행 속도와 접근성을 고려하여 실제 도착 예상 시간을 정교하게 다시 계산했습니다.
          </p>
        </div>

        {/* Route List */}
        <div className="px-4 pb-8 space-y-4">
          {filteredRoutes.length === 0 ? (
            <div className="text-center py-10 text-slate-500 font-bold">
              해당 수단으로 이동할 수 있는 경로가 없습니다.
            </div>
          ) : (
            filteredRoutes.map((route, index) => (
              <div key={route.id} className={`rounded-3xl p-5 border shadow-sm ${index === 0 ? 'bg-white border-2 border-blue-500 relative overflow-hidden' : 'bg-white border-slate-200 hover:bg-slate-50 transition-colors'}`}>
                {index === 0 && (
                  <div className="absolute top-0 right-0 px-4 py-1.5 bg-blue-600 text-white text-[10px] font-bold uppercase rounded-bl-xl tracking-tighter">추천 경로</div>
                )}
                
                <div className="flex justify-between items-start mb-5 pt-1">
                  <div>
                    <h3 className="font-extrabold text-slate-800 text-lg mb-1">{route.label}</h3>
                    <div className="flex items-end gap-1 mt-2">
                      <span className="text-4xl font-black text-slate-900 leading-none">{route.estimatedTimeMinutes}</span>
                      <span className="text-lg font-bold text-slate-800 pb-0.5">분</span>
                      
                      {route.estimatedTimeMinutes > route.baseEstimatedTime && (
                        <div className="flex items-center text-xs font-bold text-slate-400 bg-slate-100 px-2 py-1 rounded-md ml-2 mb-0.5">
                          일반 {route.baseEstimatedTime}분
                        </div>
                      )}
                    </div>
                  </div>
                  {(route as any).cost && (
                    <div className="text-lg font-black text-slate-700">
                      {(route as any).cost}
                    </div>
                  )}
                </div>

                {/* Steps */}
                <div className="space-y-0 mt-6 relative bg-slate-50 p-4 rounded-2xl border border-slate-100">
                  {route.steps.map((step, idx) => (
                    <div key={idx} className="flex gap-4">
                      <div className="flex flex-col items-center">
                        <div className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 z-10 shadow-sm ${
                          step.type === 'walk' ? 'bg-white text-slate-500 border border-slate-200' :
                          step.type === 'bus' ? 'bg-blue-500 text-white border-2 border-blue-600' :
                          step.type === 'subway' ? 'bg-[#0052A4] text-white border-2 border-[#0052A4]' :
                          'bg-emerald-500 text-white border-2 border-emerald-600'
                        }`}>
                          {step.type === 'walk' ? <Footprints className="w-4 h-4" /> : 
                           step.type === 'bus' ? <Bus className="w-4 h-4" /> : 
                           step.type === 'subway' ? <Train className="w-4 h-4" /> :
                           step.type === 'taxi' ? <Car className="w-4 h-4" /> :
                           <Clock className="w-4 h-4" />}
                        </div>
                        {idx < route.steps.length - 1 && (
                          <div className="w-[3px] h-full bg-slate-200 -mt-2 -mb-2 rounded-full"></div>
                        )}
                      </div>
                      
                      <div className="pb-7 pt-1.5 flex-1">
                        <div className="flex justify-between items-start">
                          <div className="font-extrabold text-slate-800 text-[15px]">{step.instruction}</div>
                          <span className="text-sm font-bold text-slate-500 bg-white px-2 py-0.5 rounded shadow-sm border border-slate-100">{step.time}분</span>
                        </div>
                        {step.info && (
                          <div className="text-xs font-bold text-blue-600 mt-2 bg-blue-50/50 inline-block px-2 py-1 rounded">
                            {step.info}
                          </div>
                        )}
                        {step.warnings && step.warnings.length > 0 && (
                          <div className="flex items-center gap-1 text-[11px] font-bold uppercase tracking-wide text-orange-600 bg-orange-50 inline-flex px-2 py-1.5 rounded-md mt-2 border border-orange-100">
                            <AlertTriangle className="w-3.5 h-3.5" />
                            {step.warnings.join(', ')}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
                
                {index === 0 && (
                  <button className="w-full mt-5 bg-slate-900 hover:bg-slate-800 text-white font-extrabold py-3.5 rounded-xl shadow-lg transition-all text-[15px]">
                    안내 시작
                  </button>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
