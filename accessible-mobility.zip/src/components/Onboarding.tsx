import React, { useState } from 'react';
import { UserProfile } from '../types';
import { User, Baby, Accessibility, Heart, ArrowRight, Activity } from 'lucide-react';

interface OnboardingProps {
  onComplete: (profile: UserProfile) => void;
}

export function Onboarding({ onComplete }: OnboardingProps) {
  const [step, setStep] = useState(1);
  const [email, setEmail] = useState('');
  const [userGroup, setUserGroup] = useState<'elderly_pregnant' | 'wheelchair_stroller' | 'none'>('none');

  const handleNext = () => {
    if (step === 1 && email) {
      setStep(2);
    } else if (step === 2 && userGroup !== 'none') {
      let walkSpeed = 4.0;
      let userType: UserProfile['userType'] = 'none';
      if (userGroup === 'elderly_pregnant') {
        walkSpeed = 2.5;
        userType = 'elderly';
      } else if (userGroup === 'wheelchair_stroller') {
        walkSpeed = 1.5;
        userType = 'disabled';
      }

      onComplete({ email, userType, walkSpeed });
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-[#FEE500] p-6 text-slate-900">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-xl p-8 border border-yellow-200">
        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 bg-[#FEE500] rounded-2xl flex items-center justify-center shadow-sm">
            <span className="font-black text-2xl tracking-tighter">ME</span>
          </div>
        </div>
        <h1 className="text-2xl font-extrabold tracking-tight text-slate-800 mb-2 text-center">
          {step === 1 ? 'MoveEase 로그인' : '이동 약자 유형 선택'}
        </h1>
        <p className="text-slate-500 mb-8 text-center text-sm">
          {step === 1 
            ? '이메일로 간편하게 시작하세요.'
            : '더 정확한 맞춤형 길안내를 위해 해당하는 유형을 선택해주세요.'}
        </p>

        {step === 1 ? (
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">이메일 계정</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="example@email.com"
                className="w-full px-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:ring-2 focus:ring-[#FEE500] focus:border-transparent outline-none transition-all"
              />
            </div>
            <button
              onClick={handleNext}
              disabled={!email}
              className="w-full mt-2 bg-[#FEE500] hover:bg-yellow-400 text-slate-900 font-extrabold py-3.5 rounded-xl shadow-sm transition-all disabled:opacity-50 flex items-center justify-center gap-2 text-base"
            >
              시작하기
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-1 gap-4">
              {[
                { id: 'elderly_pregnant', icons: [User, Heart], label: '임산부 / 노약자', desc: '경사도와 계단을 최소화한 경로 안내' },
                { id: 'wheelchair_stroller', icons: [Accessibility, Baby], label: '휠체어 / 유모차', desc: '저상버스와 엘리베이터 위주의 경로 안내' }
              ].map((type) => {
                const isSelected = userGroup === type.id;
                return (
                  <button
                    key={type.id}
                    onClick={() => setUserGroup(type.id as typeof userGroup)}
                    className={`flex items-center p-5 rounded-2xl border-2 transition-all cursor-pointer text-left ${
                      isSelected 
                        ? 'border-blue-500 bg-blue-50/50 text-blue-700' 
                        : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex gap-2 mr-4 text-slate-400">
                      {type.icons.map((Icon, idx) => (
                        <Icon key={idx} className={`w-7 h-7 ${isSelected ? 'text-blue-600' : 'text-slate-400'}`} />
                      ))}
                    </div>
                    <div>
                      <div className={`font-extrabold text-base ${isSelected ? 'text-blue-700' : 'text-slate-800'}`}>{type.label}</div>
                      <div className="text-xs text-slate-500 mt-1 font-medium">{type.desc}</div>
                    </div>
                  </button>
                );
              })}
            </div>
            
            <button
              onClick={handleNext}
              disabled={userGroup === 'none'}
              className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-3.5 rounded-xl shadow-lg transition-all disabled:opacity-50 mt-6 text-base"
            >
              설정 완료 및 시작
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
