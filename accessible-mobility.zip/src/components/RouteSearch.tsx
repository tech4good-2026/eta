import React, { useState } from 'react';
import { ArrowLeft, MapPin, Search, ArrowRightLeft, Clock, History } from 'lucide-react';

interface RouteSearchProps {
  onBack: () => void;
  onSearch: (origin: string, destination: string) => void;
}

export function RouteSearch({ onBack, onSearch }: RouteSearchProps) {
  const [origin, setOrigin] = useState('현재 위치');
  const [destination, setDestination] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (origin && destination) {
      onSearch(origin, destination);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 text-slate-900">
      {/* Header & Inputs */}
      <div className="bg-white shadow-[0_2px_8px_rgba(0,0,0,0.08)] z-10 pt-4">
        <div className="flex items-center px-4 pb-2">
          <button onClick={onBack} className="p-2 -ml-2 text-slate-600 hover:bg-slate-50 rounded-full transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h2 className="text-lg font-extrabold tracking-tight text-slate-800 ml-2">길찾기</h2>
        </div>

        <div className="px-5 py-4">
          <form onSubmit={handleSearch} className="flex gap-4 relative">
            {/* Connection Line */}
            <div className="flex flex-col items-center justify-center py-4 gap-2">
              <div className="w-2.5 h-2.5 rounded-full border-[2.5px] border-blue-500 bg-white shadow-sm"></div>
              <div className="flex-1 w-px bg-slate-200 border-l-[1.5px] border-dotted border-slate-400"></div>
              <div className="w-2.5 h-2.5 rounded-full bg-red-500 shadow-sm"></div>
            </div>
            
            <div className="flex-1 space-y-3">
              <div className="relative">
                <input
                  type="text"
                  value={origin}
                  onChange={(e) => setOrigin(e.target.value)}
                  placeholder="출발지를 입력하세요"
                  className="w-full px-4 py-3 bg-slate-100/80 border border-slate-200 rounded-xl text-[15px] font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 focus:bg-white outline-none transition-all placeholder:text-slate-400 placeholder:font-medium"
                />
              </div>
              <div className="relative">
                <input
                  type="text"
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                  placeholder="도착지를 입력하세요"
                  autoFocus
                  className="w-full px-4 py-3 bg-slate-100/80 border border-slate-200 rounded-xl text-[15px] font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 focus:bg-white outline-none transition-all placeholder:text-slate-400 placeholder:font-medium"
                />
              </div>
            </div>

            <button 
              type="button" 
              className="absolute right-3 top-1/2 -translate-y-1/2 p-2 bg-white rounded-full shadow-sm border border-slate-200 text-slate-500 hover:text-blue-600 hover:bg-slate-50 transition-colors"
            >
              <ArrowRightLeft className="w-4 h-4 rotate-90" />
            </button>
          </form>
          
          <button
            onClick={handleSearch}
            disabled={!origin || !destination}
            className="w-full mt-5 bg-blue-600 hover:bg-blue-700 text-white font-extrabold py-3.5 rounded-xl shadow-md disabled:opacity-50 flex items-center justify-center gap-2 transition-all"
          >
            경로 검색
          </button>
        </div>
      </div>

      {/* Recent Searches */}
      <div className="flex-1 overflow-y-auto bg-slate-50">
        <div className="p-4">
          <div className="flex items-center gap-2 mb-3 px-2">
            <History className="w-4 h-4 text-slate-400" />
            <h3 className="text-sm font-bold text-slate-500">최근 검색 및 즐겨찾기</h3>
          </div>
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            {['서울대학교병원 본관', '강남역 2번 출구', '국립재활원'].map((place, i) => (
              <div 
                key={i} 
                className={`flex items-center gap-4 py-4 px-5 hover:bg-slate-50 cursor-pointer transition-colors ${
                  i !== 2 ? 'border-b border-slate-100' : ''
                }`}
                onClick={() => setDestination(place)}
              >
                <div className="w-8 h-8 rounded-full bg-blue-50 flex items-center justify-center shrink-0">
                  <MapPin className="w-4 h-4 text-blue-600" />
                </div>
                <div className="flex-1">
                  <span className="text-slate-800 font-bold text-[15px]">{place}</span>
                  <div className="text-xs text-slate-500 mt-0.5 font-medium">서울 {place.split(' ')[0]}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
