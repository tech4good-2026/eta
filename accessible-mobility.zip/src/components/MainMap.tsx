import React from 'react';
import { Search, MapPin, Menu, Navigation } from 'lucide-react';

interface MainMapProps {
  onSearchClick: () => void;
}

export function MainMap({ onSearchClick }: MainMapProps) {
  return (
    <div className="relative w-full h-full bg-[#E5E3DF]">
      {/* Mock Map Background - TMAP Style Map Pattern */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Simple map background using CSS to simulate streets/blocks */}
        <div className="absolute w-[200%] h-[200%] -top-[50%] -left-[50%] bg-[#F2F1EC] opacity-80" 
             style={{
               backgroundImage: `
                 linear-gradient(#E8E7E1 2px, transparent 2px),
                 linear-gradient(90deg, #E8E7E1 2px, transparent 2px),
                 linear-gradient(#E8E7E1 1px, transparent 1px),
                 linear-gradient(90deg, #E8E7E1 1px, transparent 1px)
               `,
               backgroundSize: '100px 100px, 100px 100px, 20px 20px, 20px 20px',
               backgroundPosition: '-2px -2px, -2px -2px, -1px -1px, -1px -1px',
               transform: 'rotate(-15deg)'
             }}>
        </div>
        {/* River/Park shapes mock */}
        <div className="absolute top-[20%] left-[-10%] w-[120%] h-[60px] bg-[#C1D2F0] rotate-12 blur-sm rounded-[100%] opacity-80"></div>
        <div className="absolute top-[40%] right-[10%] w-[150px] h-[200px] bg-[#D7E3CB] rotate-45 blur-sm rounded-full opacity-60"></div>
      </div>
      
      {/* Current Location Marker */}
      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none z-10">
        <div className="relative">
          <div className="absolute -inset-4 bg-blue-500/20 rounded-full animate-ping"></div>
          <div className="absolute -inset-2 bg-blue-500/30 rounded-full"></div>
          <div className="w-4 h-4 bg-white rounded-full flex items-center justify-center shadow-md relative z-10">
            <div className="w-2.5 h-2.5 bg-blue-600 rounded-full"></div>
          </div>
        </div>
      </div>

      {/* Top Search Bar (KakaoMap Style) */}
      <div className="absolute top-0 left-0 right-0 p-4 z-20 pt-6">
        <div className="flex items-center gap-3">
          <button className="p-3.5 bg-white rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.12)] text-slate-700 hover:bg-slate-50 transition-all">
            <Menu className="w-6 h-6" />
          </button>
          
          <button 
            onClick={onSearchClick}
            className="flex-1 flex items-center gap-3 bg-white px-5 py-3.5 rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.12)] text-slate-500 hover:bg-slate-50 transition-all font-medium text-left"
          >
            <Search className="w-5 h-5 text-blue-600" />
            <span className="text-[15px]">장소, 주소, 버스 검색</span>
          </button>
        </div>
      </div>

      {/* Map Control Buttons */}
      <div className="absolute bottom-32 right-4 z-20 flex flex-col gap-2">
        <button className="w-12 h-12 bg-white rounded-full shadow-[0_2px_8px_rgba(0,0,0,0.12)] flex items-center justify-center text-slate-700 hover:bg-slate-50">
          <Navigation className="w-5 h-5 text-slate-600" />
        </button>
      </div>

      {/* Bottom Sheet Hint */}
      <div className="absolute bottom-4 left-4 right-4 z-20">
        <div className="bg-white rounded-2xl shadow-xl border border-slate-100 p-5 cursor-pointer" onClick={onSearchClick}>
          <div className="flex items-start justify-between">
            <div>
              <h3 className="font-extrabold text-slate-800 text-lg mb-1">어디로 갈까요?</h3>
              <p className="text-sm text-slate-500">안전하고 편안한 길을 찾아드려요</p>
            </div>
            <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center">
              <Navigation className="w-5 h-5 text-blue-600" />
            </div>
          </div>
          
          <div className="mt-4 flex gap-2">
             <div className="px-3 py-2 bg-slate-50 rounded-lg text-sm font-bold text-slate-600 flex-1 text-center">집</div>
             <div className="px-3 py-2 bg-slate-50 rounded-lg text-sm font-bold text-slate-600 flex-1 text-center">회사</div>
             <div className="px-3 py-2 bg-slate-50 rounded-lg text-sm font-bold text-slate-600 flex-1 text-center">병원</div>
          </div>
        </div>
      </div>
    </div>
  );
}
